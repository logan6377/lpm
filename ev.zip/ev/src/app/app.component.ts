import { Component } from '@angular/core';
import { EmailserviceService } from './emailservice.service';
import { Http, Response } from '@angular/http';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app';
  fileToUpload: File = null; 
  csvUrl: string = '/assets/Consolidated_5.csv';  
  csvData: any[] = [];

  uploadedData:string


  constructor (private http: Http, private email:EmailserviceService) {}

  handleFileInput(files: FileList) {
      console.log(files);
      if(files && files.length > 0) {
         let file : File = files.item(0);  

           let reader: FileReader = new FileReader();
           reader.readAsText(file);
           reader.onload = (e) => {
              this.uploadedData = reader.result;
              console.log(this.uploadedData);
              //alert(1)
           }
        }
  }

  readCsvData () {
    this.http.get(this.csvUrl)
    .subscribe(
      data => this.extractData(data),
      err => this.handleError(err)
    );
  }

  private extractData(res: Response) {

    let csvData = res['_body'] || '';

    console.log('csvData',csvData)

    let allTextLines = csvData.split(/\r\n|\n/); 

    console.log('allTextLines',allTextLines)

    allTextLines = allTextLines.filter(function(e){ return e.replace(/(\r\n|\n|\r)/gm,"")});

    console.log('allTextLines',allTextLines.length)
    
    let headers = allTextLines[0].split(',');
    console.log('headers',headers)
    let lines = [];

    for ( let i = 0; i < allTextLines.length; i++) {
      
        let data = allTextLines[i].split(',')[1];
        
        console.log('data[1]',data)

        this.email.verifyEmail(data).subscribe((res)=>{
              console.log(res);  
              lines.push(res); 
        }); 
        
        /* if (data.length == headers.length) {
            let tarr = [];
            for ( let j = 0; j < headers.length; j++) { 
                tarr.push(data[j]); 
            }
            lines.push(tarr); 
        } */
    }

    this.csvData = lines;
  }

  jsonToExcel(){
      new Angular2Csv(this.csvData, 'Verified_List', { headers: Object.keys(this.csvData[0])});
  }

  private handleError (error: any) { 
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg);  
    return errMsg;
  }


}
