$(window).on('beforeunload', function(){
    $(window).scrollTop(0);
  }); 

  var total_images = $("body img").length;
  var images_loaded = 0;
 
  $(document).ready(function(){

    $("body").find('img').each(function() {
        var fakeSrc = $(this).attr('src');
        $("<img/>").attr("src", fakeSrc).on('load',function() {
            images_loaded++;
            if (images_loaded >= total_images) {
                // now all images are loaded.
                //alert("all images are loaded. Click OK to view.") ;
                $('.se-pre-con').addClass('loaded');
                $('.pagewrap').addClass('loaded');

                $('.call-text').mouseenter(function(){
                    $('.get-appgroup').addClass('hover')
                }).mouseleave(function(){
                    $('.get-appgroup').removeClass('hover')
                })

                var scrollFirst = true; 

                var intro = function(){
                    var screenright = $(window).width()-$('.pagewrap').width();
                    //$('nav').css('right',screenright/2+'px');

                    var testi = $('[testi-slide]').height();
                    $('.testimonials').css('margin-top',-testi+'px')
                }

                intro();

                $(window).resize(function(){
                    intro();
                });

                $('.iconoMenu').click(function(){
                    $(this).toggleClass('open');
                    $('.nav').toggleClass('hideMenu');
                }); 
                    
                $('.parallax-container').height($(window).height()) 
      
 
      
                $(window).scroll(function(){
                    if(scrollFirst){
      
                        $('html, body').animate({scrollTop:$('.content-section').offset().top}, 1000)
        
                        scrollFirst = false
                    }
                })
      
                jQuery(".testimonial-slider").slick({
                  infinite:true,
                  autoplay:true,
                  speed:500,
                  arrows:false,
                  pauseOnHover:false
              }).on("afterChange",function(event, slick, currentSlide, nextSlide) {
                  $("[testi-slide]").removeClass("active");
                  $("[testi-slide="+currentSlide+"]").addClass("active")
              });
              jQuery("[testi-slide]").on("click", function() {
                  var slideNum = $(this).attr("testi-slide");
                  $(".testimonial-slider").slick("slickGoTo",slideNum);
                  $(this).addClass("active").siblings().removeClass("active");
              });
      
              $('.pov-img-container').slick({
                  infinite:true,
                  autoplay:true,
                  speed:1500,
                  arrows:false,
                  pauseOnHover:false
              });
      
              $('.nav-services li').click(function(){
                  var current = $(this).attr('class').split(' ')[0];
                  $('.nav-services li').removeClass('active')
                  $(this).addClass('active')
                  $('.service-container > div').hide();
                  $('.service-container > div.'+current).show();
              });


              var inst = $('[data-remodal-id=forms-modal]').remodal(); 
              
              //inst.open();

              $('.get-appointment').click(function(){
                inst.open(); 
              })
            }
        });
    
    });     
  });
 
 

