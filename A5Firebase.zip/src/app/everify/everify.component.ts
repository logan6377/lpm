import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
//import { Angular2Csv } from 'angular2-csv/Angular2-csv'; 

@Component({
  selector: 'app-everify',
  templateUrl: './everify.component.html',
  styleUrls: ['./everify.component.css']
})
export class EverifyComponent implements OnInit {

      title = 'JavaSampleApproach';
      description = 'Angular5-Firebase Demo';

      itemValue = '';
      items: Observable<any[]>;

      uploadedData:string;

      constructor(public db: AngularFireDatabase) {}

      onSubmit() {
            this.db.list('/items').push({ content: this.itemValue });
            this.itemValue = '';
      }

      ngOnInit() {
      }

      handleFileInput(files: FileList) { 
            console.log(files);
            if(files && files.length > 0) {
               let file : File = files.item(0);  
      
                 let reader: FileReader = new FileReader();
                 reader.readAsText(file);
                 reader.onload = (e) => {
                    this.uploadedData = reader.result;
                    console.log(this.uploadedData);
                    
                 }
              }
      }


      private extractData(res: Response) {
            let csvData = res['_body'] || ''; 
            let allTextLines = csvData.split(/\r\n|\n/); 
            allTextLines = allTextLines.filter(function(e){ return e.replace(/(\r\n|\n|\r)/gm,"")}); 
            let headers = allTextLines[0].split(','); 
            let lines = [];
            
            for ( let i = 0; i < allTextLines.length; i++) {
                  
                  let data = allTextLines[i].split(',')[1]; 
            
                  /* this.email.verifyEmail(data).subscribe((res)=>{
                        console.log(res);  
                        lines.push(res); 
                  }); */ 
            }
            //this.csvData = lines;
      }
      
      jsonToExcel(){
            //new Angular2Csv(this.csvData, 'Verified_List', { headers: Object.keys(this.csvData[0])});
      }
      
      private handleError (error: any) { 
      let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
                  console.error(errMsg);  
            return errMsg;
      }

} 

