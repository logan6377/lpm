import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class EmailcheckService {

      private api = 'https://app.verify-email.org/api/v1/jjZodIbEGuz4Mk88b8WLLdntzCflkWx2qZ88WMUMNiC9g9C8zr/verify/'

      constructor(private http:HttpClient) { 
    
      }
    
      verifyEmail(email){
          console.log(this.api+email)
          return this.http.get(this.api+email, {headers: new HttpHeaders().set('Content-Type', 'application/json')});
      }

}
