import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-everify-list',
  templateUrl: './everify-list.component.html',
  styleUrls: ['./everify-list.component.css']
})
export class EverifyListComponent implements OnInit {

itemValue = '';
items: Observable<any[]>;

constructor(public db: AngularFireDatabase) {
      this.items = db.list('items').valueChanges();
}

  ngOnInit() {
  }

}
